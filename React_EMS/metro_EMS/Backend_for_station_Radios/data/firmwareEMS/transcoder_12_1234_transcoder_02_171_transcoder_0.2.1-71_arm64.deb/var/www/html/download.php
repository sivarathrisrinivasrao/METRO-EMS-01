<?php


function downlaod11() {
	$file = '/opt/transcoder/transcoder.ini';
	
	if(!file_exists($file)){ // file does not exist
    		die('file not found');
	} else {
	    header('Content-Description: File Transfer');
				header('Content-Disposition: attachment; filename='.basename($file));
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($file));
				header("Content-Type: text/plain");
				readfile($file);

	    // read the file from disk
	    //readfile($file);
		
	}
}

downlaod11();

?>
