#!/bin/bash

newip=$1
newmask=$2
newgw=$3
oldip=""
oldmask=""
oldgw=""
cfgsysip=$4
cfgntpip=$5
cfghost=$6
cursysip=$(grep -i :514 /etc/rsyslog.conf | awk -F':' '{print $1}' | awk -F'@' '{print $2}')
curntpip=$(grep -i sntpip /etc/ntp.conf | awk -F' ' '{print $2}')
curhost=$(hostnamectl | grep -i hostname | awk '/:/{print $3}')

#IP address configuration
if [ -f /etc/network/interfaces.d/ifcfg-eth0 ]; then
    oldip=$(awk '/address/{print $2}' /etc/network/interfaces.d/ifcfg-eth0)
    oldmask=$(awk '/netmask/{print $2}' /etc/network/interfaces.d/ifcfg-eth0)
    oldgw=$(awk '/gateway/{print $2}' /etc/network/interfaces.d/ifcfg-eth0)

    perl -p -i -e "s/address $oldip/address $newip/" \
        /etc/network/interfaces.d/ifcfg-eth0
    perl -p -i -e "s/netmask $oldmask/netmask $newmask/" \
        /etc/network/interfaces.d/ifcfg-eth0
    perl -p -i -e "s/gateway $oldgw/gateway $newgw/" \
        /etc/network/interfaces.d/ifcfg-eth0
else
    echo auto eth0 > /etc/network/interfaces.d/ifcfg-eth0
    echo iface eth0 inet static >> /etc/network/interfaces.d/ifcfg-eth0
    echo address $newip >> /etc/network/interfaces.d/ifcfg-eth0
    echo netmask $newmask >> /etc/network/interfaces.d/ifcfg-eth0
    echo gateway $newgw >> /etc/network/interfaces.d/ifcfg-eth0
fi

if [[ "$oldip" == "$newip" ]] && [[ "$oldmask" == "$newmask" ]] && [[ "$oldgw" == "$newgw" ]]; then
    echo same config
else
    service networking restart
    sleep 3
    intfip=$(ifconfig eth0 | grep -i inet | awk '/^        inet /{print $2}')
    currip=$(ip address | grep -w "$intfip" | awk -F' ' '{print $2}')
    ip address del $currip dev eth0
fi

#Syslog IP configuration
if [ ! -z "$cfgsysip" ]; then
    if [ "$cfgsysip" == "0" ]; then
        rm -f /etc/rsyslog.d/55-remote.conf
   else
        echo "*.* @$cfgsysip:514" > /etc/rsyslog.d/55-remote.conf
    fi
    service rsyslog restart
fi

#SNTP IP configuration
if [ ! -z "$cfgntpip" ]; then
    if [ ! -z "$curntpip" ]; then
        perl -p -i -e "s/server $curntpip #sntpip/server $cfgntpip #sntpip/" \
            /etc/ntp.conf
        service ntp restart
    fi
fi

#hostname configuration
if [ "$cfghost" != "$curhost" ];then
    hostnamectl set-hostname $cfghost
fi

#Restarting vtranscoder process
systemctl start transcoder
sync
