<html>
    <head>
        <meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="styles.css">
	<link rel="stylesheet" href="fontawesome-4.7.0/css/font-awesome.min.css"> 
<?php 
session_start();
//include 'saveToIni.php';
$nwkip = '';
	$nwkmask = '';
	$sysname = '';
	$nwkgip = '';
	$sntpip = '';
	$syslogip = '';
	$dPath = $_SESSION["dPath"];
	$fileName=$_SESSION["inifile"];
	if (file_exists($dPath."transcoder.ini"))
        {
        	$fileName = "transcoder.ini";
        }
	$pCheck = 0;
        $currCheck=0;
	$pData = parse_ini_file($dPath."".$fileName, true);
	if (!empty($pData)) {
		$systemArray = $pData['System'];
		if (!empty($systemArray)) {
			$nwkip = $systemArray['nwkip'];
			$nwkmask = $systemArray['nwkmask'];
			$sysname = $systemArray['sysname'];
			$nwkgip = $systemArray['nwkgip'];
			$sntpip = $systemArray['sntpip'];
			$logenable = $systemArray['logenable'];
			if (strcmp($logenable,"1") == 0) {
			   $logenable = 'checked';
			} else {
			   $logenable = ' ';
			}
			$syslogip = $systemArray['syslogip'];
			$pCheck = $systemArray['pchecksum'];
	                $currCheck = $systemArray['checksum'];
		}
	}
	//}
	include 'checksum.php';
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		//print_r($_POST);
		$option = $_POST["option"];
		if (strcmp($option,"Save") == 0) {
			$nwkip = $_POST["nwkip"];
			$nwkgip = $_POST["nwkgip"];
			$nwkmask = $_POST["nwkmask"];
			$syslogip = $_POST["syslogip"];
			$sntpip = $_POST["sntpip"];
			$pData['System']['nwkip'] = $_POST["nwkip"];
			$pData['System']['sysname'] = $_POST["sysname"];
			$pData['System']['nwkgip'] = $_POST["nwkgip"];
			$pData['System']['sntpip'] = $_POST["sntpip"];
			$pData['System']['nwkmask'] = $_POST["nwkmask"];
			if(strcmp($_POST["logenable"],"on") == 0) {
			    $pData['System']['logenable'] = "1";
			    $logenable = 'checked';
			} else {
			    $pData['System']['logenable'] = "0";
			    $logenable = ' ';
			}
			$pData['System']['syslogip'] = $_POST["syslogip"];
			$currCheck = calculateCheckSum($pData);
		        $pData['System']['checksum'] = $currCheck;
			write_ini_file($dPath.''."transcoder.ini",$pData);
			echo '<script>alert("Configuration modified successfully.")</script>'; 
			header("Refresh:0");
		}
		//else if (strcmp($option,"Apply") == 0) {
		//	$cmd = 'sudo bash changeip.sh '.$nwkip.' '.$nwkmask.' '.$nwkgip.' '.$syslogip.' '.$sntpip;
		//	shell_exec($cmd);
		//	}
}
?>

    </head>
    <body>
        <div class="container">
<?php include 'header.php';?>
            <div class="childcont">
		<div class="sidebar">
		    <a href="#" style="background-color: #663399;color: #fff;">
                        <i class="fa fa-cog fa-lg" aria-hidden="true"></i>
                        Network
                    </a>
                    <a href="camerainput.php">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                        Camera Input
                    </a>
                    <a href="quadoutput.php">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                        Quad Output
                    </a>
                    <a href="system.php">
                        <i class="fa fa-desktop"  aria-hidden="true"></i>
                        Management
                    </a>
                </div>
		<div class="mainview">
                    <div class="subview">
                        <form id="formTable" aciton="" method="post">
		          <br>
                            <div class="section">
			    <label class="lblview">System Name</label>
                                <input class="paramview" type="text" name="sysname" value="<?php echo $sysname ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">IP Address</label>
                                <input class="paramview" type="text" name="nwkip" value = "<?php echo $nwkip ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">Subnet Mask</label>
                                <input class="paramview" type="text" name="nwkmask" value = "<?php echo $nwkmask ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">Gateway IP</label>
                                <input class="paramview" type="text" name="nwkgip" value = "<?php echo $nwkgip ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">SNTP Server IP</label>
                                <input class="paramview" type="text" name="sntpip" value = "<?php echo $sntpip ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">Remote logging</label>
                                <input type="checkbox" id="logenable" name="logenable" value="on" <?php echo "$logenable" ?>>
                            </div>
                            <div class="section">
                                <label class="lblview">Syslog Server IP</label>
                                <input class="paramview" type="text" name="syslogip" value = "<?php echo $syslogip ?>">
			    </div>
				<div class="btnview">
				<input class="actbtn" type="submit" name="option" value="Save">
				</div>		
                        </form>
                    </div>
                </div>
            </div>
	</div>
<?php include 'footer.php';?>
    </body>
</html>
