<html>
<h1> Device apply rebbot`Rebooting....</h1>
</html>

<?php
//include 'checksum.php';
exec('sudo reboot');

?>
