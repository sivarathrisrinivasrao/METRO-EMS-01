<html>
    <head>
        <meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="fontawesome-4.7.0/css/font-awesome.min.css">
<?php
session_start();
//include 'saveToIni.php';
	$xpos = '';
	$ypos = '';
	$profile = '';
	$bitrate = '';
	$dPath = $_SESSION["dPath"];
	$fileName=$_SESSION["inifile"];
	if (file_exists($dPath."transcoder.ini"))
        {
        	$fileName = "transcoder.ini";
        }
	$pCheck = 0;
        $currCheck=0;
	$pData = parse_ini_file($dPath."".$fileName, true);
	if (!empty($pData)) {
		$urlArray = $pData['Quad'];
		if (!empty($urlArray)) {
			$xpos = $urlArray['xpos'];
			$ypos = $urlArray['ypos'];
			$profile = $urlArray['profile'];
			$bitrate = $urlArray['bitrate'] / 1000;
		}
		$urlArray = $pData['System'];
                $pCheck = $urlArray['pchecksum'];
                $currCheck = $urlArray['checksum'];
	}
	include 'checksum.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$xpos = $_POST["xpos"];
		$ypos = $_POST["ypos"];
		$profile = $_POST["profile"];
		$bitrate1 = $_POST["bitrate"] * 1000;

	$pData['Quad']['xpos'] = $xpos;
	$pData['Quad']['ypos'] = $ypos;
	$pData['Quad']['profile'] = $profile;
	$pData['Quad']['bitrate'] = $bitrate1;
	$currCheck = calculateCheckSum($pData);
        $pData['System']['checksum'] = $currCheck;
	write_ini_file($dPath.''."transcoder.ini",$pData);
	echo '<script>alert("Configuration applied successfully.")</script>'; 
	header("Refresh:0");
}
?>
    </head>
    <body>
        <div class="container">
<?php include 'header.php';?>
	    <div class="childcont">
		<div class="sidebar">
                    <a href="config.php">
                        <i class="fa fa-cog fa-lg" aria-hidden="true"></i>
                        Network
                    </a>
                    <a href="camerainput.php">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                        Camera Input
                    </a>
                    <a href="#" style="background-color: #663399;color: #fff;">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                        Quad Output
                    </a>
                    <a href="system.php">
                        <i class="fa fa-desktop"  aria-hidden="true"></i>
                        Management
                    </a>
                </div>
		<div class="mainview">
		    <div class="subview">
			<legend>Stream Profile</legend>
                        <form id="formTable" action="" method="post">
                            <div class="section">
                                <label class="lblview">X-pos</label>
                                <input class="paramview" type="text" name="xpos" value="<?php echo $xpos ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">Y-pos</label>
                                <input class="paramview" type="text" name="ypos" value="<?php echo $ypos ?>">
                            </div>
                            <div class="section">
                                <label class="lblview">Profile</label>
				<?php 
				$plan = array('1' => 'Base','2'=>'Main','3'=>'High' );
				?>
				<select class="selectview" title="Select" name="profile">
				<?php foreach ($plan as $key => $value) { ?>
  					<option value="<?php echo $key;?>" <?php echo ($key == $profile ) ? ' selected="selected"' : '';?>><?php echo $value;?></option>
				<?php } ?>
				</select>
                            </div>
                            <div class="section">
                                <label class="lblview">Bitrate</label>
                                <input class="paramview" type="text" name="bitrate" value="<?php echo $bitrate ?>"> (kbps)
                            </div>
                    		<div class="btnview">
                        		<input class="actbtn" type="submit" name="quadsave" value="Save">
                    		</div>
                        </form>
                    </div>
                </div>
            </div>
	</div>
<?php include 'footer.php';?>
    </body>
</html>
