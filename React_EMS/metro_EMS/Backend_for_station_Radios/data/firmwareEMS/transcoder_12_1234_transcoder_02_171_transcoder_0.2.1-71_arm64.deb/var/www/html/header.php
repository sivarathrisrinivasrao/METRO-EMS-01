<?php
//	include 'checksum.php';	
	$color = "";
	if ($pCheck != $currCheck) {
		$color="color:red";
	}
echo "<div class=\"headertile\">
          <div class=\"logoimg\">
              <a href=\"summary.php\"><img src=\"kwn-logo-img.png\"></a>
          </div>
          <div class=\"fwicons\">
              <a href=\"summary.php\">
                  <i class=\"fa fa-home fa-2x\" aria-hidden=\"true\" title=\"Home\"></i>
              </a>
	      <a href=\"applyProfile.php?meth=save\" style=$color onclick=\"return confirm('Are you sure you wish to reload the configuration?')\">
                  <i class=\"fa fa-floppy-o fa-2x\" aria-hidden=\"true\" title=\"Apply\"></i> 
              </a>
              <a href=\"reboot.html\" onclick=\"return confirm('Are you sure you wish to reboot?')\">
                  <i class=\"fa fa-power-off fa-2x\" aria-hidden=\"true\" title=\"Reboot\"></i>
              </a>
              <a href=\"applyProfile.php?meth=logout\" onclick=\"return confirm('Are you sure you wish to logout?')\">
                  <i class=\"fa fa-sign-out fa-2x\" aria-hidden=\"true\" title=\"Logout\"></i>
              </a>
           </div>
       </div>"
?>
