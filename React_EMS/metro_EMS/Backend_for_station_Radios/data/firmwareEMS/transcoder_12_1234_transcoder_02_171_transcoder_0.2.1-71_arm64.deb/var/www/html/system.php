<html>
    <head>
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="styles.css">
	<link rel="stylesheet" href="fontawesome-4.7.0/css/font-awesome.min.css">
<?php
session_start();
$transStatus = exec("ps aux | grep -i 'vtranscoder' | grep -v grep",$pids);
$bLabel = 'Start';
$rStatus = 'Stopped';
if (empty($pids)) {
	$bLabel = 'Start';
} else {
	$bLabel = 'Stop';
	$rStatus = 'Running';
}
$dPath = $_SESSION["dPath"];
$fileName=$_SESSION["inifile"];
if (file_exists($dPath."transcoder.ini"))
{
	$fileName = "transcoder.ini";
}
$pCheck = 0;
$currCheck=0;

$pData = parse_ini_file($dPath."".$fileName, true);
        if (!empty($pData)) {
                $systemArray = $pData['System'];
                if (!empty($systemArray)) {
                        $nwkip = $systemArray['nwkip'];
                        $nwkmask = $systemArray['nwkmask'];
                        $sysname = $systemArray['sysname'];
                        $nwkgip = $systemArray['nwkgip'];
                        $sntpip = $systemArray['sntpip'];
                        $syslogip = $systemArray['syslogip'];
                        $pCheck = $systemArray['pchecksum'];
                        $currCheck = $systemArray['checksum'];
                }
        }

include 'checksum.php';
if($_SERVER["REQUEST_METHOD"] == "POST") {
		//$sttop =  $_POST["ststop"];
		//$sttop = array_key_exists('Save', $_POST);
		$method = "";
		foreach($_POST as $flower){
			
			if (strlen($flower) > 0 ) {
				
				$method = $flower;
			}
		}
		
		if (strcmp($method,"Save")==0) {
			$curpass = $_POST["curpass"];
			$newpass = $_POST["newpass"];
			$username = 'transcoder';
			$cmd = sprintf(
   				 "echo '%s:%s' | sudo chpasswd",
    					escapeshellarg($username),
    					escapeshellarg($newpass)
				);
			exec($cmd);
			echo '<script>alert("Password modified successfully.")</script>';
		} else if (strcmp($method,"Start")==0) {
			shell_exec("sudo systemctl start transcoder");
			 shell_exec("sudo sync");
			$bLabel = "Stop";
			$rStatus = "Running";
			$url = 'http://'.$_SERVER['HTTP_HOST'].'/system.php';
                	header( "Location: $url" );
		} else if (strcmp($method,"Stop")==0) {
			shell_exec("sudo systemctl stop transcoder");
			$bLabel = "Start";
			$rStatus = "Stopped";
			$url = 'http://'.$_SERVER['HTTP_HOST'].'/system.php';
                	header( "Location: $url" );
		} else if (strcmp($method,"Backup")==0) {

			$url = 'http://'.$_SERVER['HTTP_HOST'].'/download.php';
			header( "Location: $url" );
		} 
	} else {
		$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		//echo "".$url;
		$components = parse_url($url);
		parse_str($components['query'], $results);
		$status = $results['status'];
		if ($status == "success") {
			echo '<script>alert("File uploaded successfully.")</script>';
			shell_exec("sudo systemctl start transcoder");
		}
	}

?>
        <script>
            function curdisplaypass() {
                var pwd = document.getElementById("curpass");
                var img = document.getElementById("curimgsrc");
                if( pwd.type == "password" && pwd.value != "" ) {
                    pwd.type="text";
                    img.src="icons8-eye-24_2.png";
                } else {
                    pwd.type="password";
                    img.src="icons8-eye-24_1.png";
                }
	    } 
 	    function newdisplaypass() {
                var pwd = document.getElementById("newpass");
                var img = document.getElementById("newimgsrc");
                if( pwd.type == "password" && pwd.value != "" ) {
                    pwd.type="text";
                    img.src="icons8-eye-24_2.png";
                } else {
                    pwd.type="password";
                    img.src="icons8-eye-24_1.png";
                }
            }
        </script>
    </head>
    <body>
        <div class="container">
<?php include 'header.php';?>
            <div class="childcont">
                <div class="sidebar">
                    <a href="config.php">
                        <i class="fa fa-cog fa-lg" aria-hidden="true"></i>
                        Network
                    </a>
                    <a href="camerainput.php">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                        Camera Input
                    </a>
                    <a href="quadoutput.php">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                        Quad Output
                    </a>
                    <a href="#" style="background-color: #663399;color: #fff;">
                        <i class="fa fa-desktop"  aria-hidden="true"></i>
                        Management
                    </a>
                </div>
                <div class="mainview">
                    <div class="subview">
                        <legend>Login</legend>
                        <form id="formTable" action="" method="post">
                            <div class="section">
                                <label class="lblview">Current Password</label>
                                <input class="paramview" id="curpass" type="password" name="curpass">
                                <i class="pass_eye" onclick="curdisplaypass()">
                                    <img id="curimgsrc" src="icons8-eye-24_1.png">
                                </i>
			    </div>
			    <div class="section">
                                <label class="lblview">New Password</label>
                                <input class="paramview" id="newpass" type="password" name="newpass">
                                <i class="pass_eye" onclick="newdisplaypass()">
                                    <img id="newimgsrc" src="icons8-eye-24_1.png">
                                </i>
			    </div>
			    <div class="btnview">
                                <input class="actbtn" type="submit" name="syssave" value="Save">
                            </div>
			</form>
                    </div>
		    <div>
			<form id="quead"   action="" method="post">
		                <legend>Transcoder</legend>
		                <label class="translabel">Quad Streaming</label>
				<input class="transactbtn" type="submit" name="ststop" value="<?php echo $bLabel; ?>">
				<label class="transvalue"><?php echo $rStatus; ?></label>
		        </form>
                    </div>
                    <div>
                        <label class="resetlabel">Reset to Factory Defaults</label>
                        <div class="resetbtnview"><a class="resetactbtn" href="reset.html" onclick="return confirm('Are you sure you want to reset to factory?')">Reset</a></div>
                    </div>
		    <div>
			<legend>Backup/Export</legend>
			<div>
				<form id="backup"   action="" method="post">
		                	<label class="configlabel">Configuration</label>
					<input class="transactbtn" type="submit" name="ststop" value="Backup">
		        	</form>
			</div>
			<div>
				<form id=""   action="/exportlogs.php" method="post">
				       
				       	<label class="loglabel">Logs</label>
					<input class="logbtn" type="submit" name="ststop" value="Export">
				</form>
			</div>
                    </div>
		    <div>
			<form id="restore"  action="/upload.php" method="post" enctype="multipart/form-data">
		                <legend>Restore</legend>
		               <div style="margin-left:200px;margin-bottom:10px;">
				 <input type="file" name="fileToUpload" id="fileToUpload"> 
				</div>
				
				<input class="backupbtn" type="submit" name="ststop" value="Restore">
				
		        </form>
                   </div>
	           <div>
			
                    </div>
                </div>
            </div>
	</div>
<?php include 'footer.php';?>
    </body>
</html>
