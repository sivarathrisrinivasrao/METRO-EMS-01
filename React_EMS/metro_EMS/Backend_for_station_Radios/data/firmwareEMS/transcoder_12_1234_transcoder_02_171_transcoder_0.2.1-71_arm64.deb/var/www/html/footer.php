<?php
echo '<div class="footer">
    @2021, Copyright Systems Integrated. ALL RIGHTS RESERVED.
</div>'
?>
