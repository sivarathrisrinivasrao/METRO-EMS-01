<html>
    <head>
        <meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="fontawesome-4.7.0/css/font-awesome.min.css">
<?php
session_start();
//include 'saveToIni.php';
//include 'checksum.php';
	$cam1 = '';
	$cam2 = '';
	$cam3 = '';
	$cam4 = '';
	$latency = '';
	$dPath = $_SESSION["dPath"];
	$fileName=$_SESSION["inifile"];
	if (file_exists($dPath."transcoder.ini"))
        {
        	$fileName = "transcoder.ini";
        }
	$pData = parse_ini_file($dPath."".$fileName, true);
	$pCheck = 0;
	$currCheck=0;
	if (!empty($pData)) {
		$urlArray = $pData['RSTPURL'];
		
		if (!empty($urlArray)) {
			$cam1 = $urlArray['cam1.url'];
			$cam2 = $urlArray['cam2.url'];
			$cam3 = $urlArray['cam3.url'];
			$cam4 = $urlArray['cam4.url'];
			$latency = $urlArray['latency'];


		}
		$urlArray = $pData['System'];
		$pCheck = $urlArray['pchecksum'];
		$currCheck = $urlArray['checksum'];
	}
	include 'checksum.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$cam1 = $_POST["cam1"];
	$cam2 = $_POST["cam2"];
	$cam3 = $_POST["cam3"];
	$cam4 = $_POST["cam4"];
	$latency = $_POST["latency"];
	$pData['RSTPURL']['cam1.url'] = $cam1;
	$pData['RSTPURL']['cam2.url'] = $cam2;
	$pData['RSTPURL']['cam3.url'] = $cam3;
	$pData['RSTPURL']['cam4.url'] = $cam4;
	$pData['RSTPURL']['latency'] = $latency;
	$currCheck = calculateCheckSum($pData);
	$pData['System']['checksum'] = $currCheck;
	write_ini_file($dPath.''."transcoder.ini",$pData);
	echo '<script>alert("Configuration modified successfully.")</script>';
	header("Refresh:0");
}
	
?>
    </head>
    <body>
	<div class="container">
<?php include 'header.php';?>
            <div class="childcont">
		<div class="sidebar">
		    <a href="config.php">
                        <i class="fa fa-cog fa-lg" aria-hidden="true"></i>
                        Network
                    </a>
                    <a href="#" style="background-color: #663399;color: #fff;">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                        Camera Input
                    </a>
                    <a href="quadoutput.php">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                        Quad Output
                    </a>
                    <a href="system.php">
                        <i class="fa fa-desktop"  aria-hidden="true"></i>
                        Management
                    </a>
                </div>
		<div class="mainview">
		    <div class="subview">
			<legend>RTSP Stream URL</legend>
                        <form id="formTable" action="" method="post">
                            <div class="section">
				<label class="lblview">Camera 1</label>
                                <input class="camparamview" type="text" name="cam1" value="<?php echo $cam1 ?>">
                            </div>
                            <div class="section">
				<label class="lblview">Camera 2</label>
                                <input class="camparamview" type="text" name="cam2" value="<?php echo $cam2 ?>">
                            </div>
                            <div class="section">
				<label class="lblview">Camera 3</label>
                                <input class="camparamview" type="text" name="cam3" value="<?php echo $cam3 ?>">
                            </div>
                            <div class="section">
				<label class="lblview">Camera 4</label>
                                <input class="camparamview" type="text" name="cam4" value="<?php echo $cam4 ?>">
			    </div>
				<legend>RTSP Stream Buffer</legend>
                            <div class="section">
                                <label class="lblview">Latency</label>
                                <input class="paramview" type="text" name="latency" value="<?php echo $latency ?>"> (ms)
                            </div>
                            <div class="btnview">
                        	<input class="actbtn" type="submit" name="camsave" value="Save">
                    	    </div>
			</form>
			<div class="note">
                            Note:<br>
                            Sample RTSP Stream URLs:<br>
                            Axis Cameras  - rstp://192.168.1.21/axis-media/media.amp?streamprofile=tdm<br>
                            Axis Cameras  - rtsp://192.168.1.21/axis-media/media.amp<br>
                            Bosch Cameras - rtsp://192.168.1.21/?h26x=4
                        </div>
                    </div>
                </div>
            </div>
	</div>
<?php include 'footer.php';?>
    </body>
</html>
