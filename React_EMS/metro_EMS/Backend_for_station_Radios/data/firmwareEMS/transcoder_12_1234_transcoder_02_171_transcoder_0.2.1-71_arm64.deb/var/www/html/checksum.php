<?php
include 'saveToIni.php';
	function applyChecksum() {
		$dPath = '/opt/transcoder/';
		$fileName="default.ini";
		if (file_exists($dPath."transcoder.ini"))
        	{
                	$fileName = "transcoder.ini";
        	}
		
		$pData = parse_ini_file($dPath."".$fileName, true);
		$key="checksum";
		if (($key = array_search($key, $pData)) !== false) {
    			unset($pData[$key]);
		}
		if (($key = array_search("pchecksum", $pData)) !== false) {
                        unset($pData[$key]);
                }
		$checksumStr = serialize($pData);
		$checksum = crc32($checksumStr);
		$pData['System']['checksum']=$checksum;
		$pData['System']['pchecksum']=$checksum;
		print_r($pData);
		write_ini_file($dPath.''."transcoder.ini",$pData);
	}
	function calculateCheckSum($pData) {
		if (($key = array_search("checksum", $pData)) !== false) {
                        unset($pData[$key]);
		}
		if (($key = array_search("pchecksum", $pData)) !== false) {
                        unset($pData[$key]);
                }
                $checksumStr = serialize($pData);
		$checksum = crc32($checksumStr);
		return $checksum;
	}

?>
