<?php
	function ale() {
	
	echo "<script>
		function ale() {
			return 'asdf';
		}
	</script>";
	echo $var;
	}
?>
