<?php
include 'checksum.php';
$func = $_GET['meth'];
	session_start();
	if (strcmp($func,"save") == 0) {
		save();
	} else if (strcmp($func,"reboot") == 0) {
		exec('sudo reboot');	
	} else if (strcmp($func,"logout") == 0) {
		$url = 'http://'.$_SERVER['HTTP_HOST'];
		header( "Location: $url" );
	}
	function save() {
		$dPath = $_SESSION["dPath"];
		$fileName=$_SESSION["inifile"];
		if (file_exists($dPath."transcoder.ini"))
		{
        		$fileName = "transcoder.ini";
		}
		$xpos = '';$ypos = '';$profile = '';$bitrate = '';
		$cam1='';$cam2='';$cam3='';$cam4='';$latency='';
		$pData = parse_ini_file($dPath."".$fileName, true);

		if (!empty($pData)) {
			$urlArray = $pData['Quad'];
			if (!empty($urlArray)) {
				$xpos = $urlArray['xpos'];
				$ypos = $urlArray['ypos'];
				$profile = $urlArray['profile'];
				$bitrate = $urlArray['bitrate'] * 1000;
			}
			$camArray = $pData['RSTPURL'];
			if (!empty($camArray)) {
				$cam1 = $camArray['cam1.url'];
				$cam2 = $camArray['cam2.url'];
				$cam3 = $camArray['cam3.url'];
				$cam4 = $camArray['cam4.url'];
				$latency =  $camArray['latency'];
			}
			$systemArray = $pData['System'];
                	if (!empty($systemArray)) {
                        	$nwkip = $systemArray['nwkip'];
                        	$nwkmask = $systemArray['nwkmask'];
                        	$sysname = $systemArray['sysname'];
                        	$nwkgip = $systemArray['nwkgip'];
                        	$sntpip = $systemArray['sntpip'];
                        	$logenable = $systemArray['logenable'];
                        	$syslogip = $systemArray['syslogip'];
                        	$pCheck = $systemArray['pchecksum'];
                        	$currCheck = $systemArray['checksum'];
                	}
		}
		shell_exec("sudo systemctl stop transcoder");
		sleep(3);
		/*exec("sudo rm -rf /opt/transcoder/transcoder.conf"); 
		$str = "";
		$str.=	"RUN_CFG= \"(videomixer name=comp \\\n";
		$str.=  "sink_0::xpos=0 sink_0::ypos=0 \\\n";
		$str.=	"sink_1::xpos=".$xpos." sink_1::ypos=0 \\\n";
		$str.=	"sink_2::xpos=0 sink_2::ypos=".$ypos." \\\n";
		$str.=  "sink_3::xpos=".$xpos." sink_3::ypos=".$ypos." ! \\\n";
		$str.=	"videoconvert ! omxh264enc profile=".$profile." control-rate=2 low-latency=1 peak-bitrate=".$bitrate." preset-level=0 ! rtph264pay config-interval=-1 name=pay0 pt=96 \\\n";
		$str.=	"rtspsrc latency=".$latency." location=".$cam1." ! rtph264depay ! h264parse ! omxh264dec ! comp.sink_0 \\\n";
		$str.=	"rtspsrc latency=".$latency." location=".$cam2." ! rtph264depay ! h264parse ! omxh264dec ! comp.sink_1 \\\n";
		$str.=	"rtspsrc latency=".$latency." location=".$cam3." ! rtph264depay ! h264parse ! omxh264dec ! comp.sink_2 \\\n";
		$str.=	"rtspsrc latency=".$latency." location=".$cam4." ! rtph264depay ! h264parse ! omxh264dec ! comp.sink_3 )\" &";
		$myfile = fopen("/opt/transcoder/transcoder.conf", "w");*/
		//fwrite($myfile,$str);
		//fclose($myfile);
		applyChecksum($pData);
		shell_exec("sudo sync");
		if (strcmp($logenable,"0") == 0) {
		    $syslogip = 0;
		}
		$cmd = 'sudo bash changeip.sh '.$nwkip.' '.$nwkmask.' '.$nwkgip.' '.$syslogip.' '.$sntpip.' '.$sysname;
		shell_exec($cmd);
		shell_exec("sudo systemctl start transcoder");		
		sleep(15);
		$url = 'http://'.$nwkip.'/summary.php';
		header( "Location: $url" );
	}

?>
