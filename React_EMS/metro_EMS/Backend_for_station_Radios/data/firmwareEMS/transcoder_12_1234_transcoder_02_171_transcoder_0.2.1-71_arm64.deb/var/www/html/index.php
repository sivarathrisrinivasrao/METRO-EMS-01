<?php
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = $_POST["username"];
	$password = $_POST["password"];

	$error = authenticate($username,$password);
	if ($error) {
		$_SESSION["dPath"] = "/opt/transcoder/";
		header("location: summary.php");
	} else {
		$error = "Your Login Name or Password is invalid";
	}
}
function authenticate($user, $pass){
  $shad =  preg_split("/[$:]/",`sudo cat /etc/shadow | grep "^$user\:"`);
  $mkps = preg_split("/[$:]/",trim(`sudo mkpasswd -m sha-512 $pass $shad[3]`));
  return ($shad[4] == $mkps[3]);
}
?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Login</title>
        <Link rel="stylesheet" href="loginstyle.css">
        <script>
            function displaypass() {
                var pwd = document.getElementById("showpass");
                var img = document.getElementById("imgsrc");
                var pwdwidth = document.getElementById("showpass");
                if( pwd.type == "password" && pwd.value != "" ) {
                    pwd.type="text";
                    img.src="icons8-eye-24_2.png";
                    pwdwidth.style.paddingRight="33px";
                } else {
                    pwd.type="password";
                    img.src="icons8-eye-24_1.png";
                    pwdwidth.style.paddingRight="33px";
                }
            }
            function resetfun() {
                var img = document.getElementById("imgsrc");
                var pwd = document.getElementById("showpass");
                var pwdwidth = document.getElementById("showpass");
                pwd.type="password";
                img.src="icons8-eye-24_1.png";
                pwdwidth.style.paddingRight="33px";
            }
        </script>
    </head>
    <body>
        <div class="box">
            <form action = "" method = "post">
                <h2>Authorization Required</h2>
                <div class="lbldescr">
                <label>Please enter your username and password.</label>
                </div>
                <div class="maincard">
                    <div class="section">
                        <label class="lblview">Username</label>
                        <input class="paramview" id="showuser" type="text" name="username">
                    </div>
                    <div class="section">
                        <label class="lblview">Password</label>
                        <input class="paramview" id="showpass" type="password" name="password">
                        <i class="pass_eye" onclick="displaypass()">
                            <img id="imgsrc" src="icons8-eye-24_1.png">
                        </i>
                    </div>
                </div>
                <div class="btns">
                    <input class="actbtn" type="submit" name="syssave" value="Login">
                    <input class="actbtn" type="reset" name="sysreset" value="Reset" onclick="resetfun()">
                </div>
		 <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
            </form>
        </div>
    </body>
</html>
