<html>
    <head>
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="fontawesome-4.7.0/css/font-awesome.min.css"> 
<?php
session_start();
	$xpos = '';
	$ypos = '';
	$profile = '';
	$bitrate = '';$cam1='';$cam2='';$cam3='';$cam4='';$latency='';
	$nwkmask = '';
	$sysname = '';
	$nwkgip = '';
	$sntpip = '';
	$syslogip = '';
	$model = '';
	$serial = '';
	$firmware = '';
	$hardware = '';
	$pCheck = 0;
        $currCheck=0;
	$transStatus = exec("ps aux | grep -i 'vtranscoder' | grep -v grep",$pids);
	$rStatus = 'Stopped';
	if (!empty($pids)) {
        	$rStatus = 'Running';
	}
	exec('cat /sys/class/hwmon/hwmon0/temp1_input',$temp);
	$temp = round($temp[0]/1000,2);
        $fileName = "default.ini";
        $dPath = $_SESSION["dPath"];
        if (file_exists($dPath."transcoder.ini"))
        {
                $fileName = "transcoder.ini";
	}
	$cpucomm = "grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage ''}'";
	exec($cpucomm,$cpu);
	$cpu = round($cpu[0],2);
	$totMem = "free -m  | grep ^Mem | tr -s ' ' | cut -d ' ' -f 2";
	$useMem = "free -m  | grep ^Mem | tr -s ' ' | cut -d ' ' -f 3";
	exec($useMem,$useMem);
	exec($totMem,$totMem);
	$memPer = $useMem[0]*100;
	$memPer = round($memPer/$totMem[0],2);
	$str   = @file_get_contents('/proc/uptime');
	$num   = floatval($str);
	$secs  = fmod($num, 60); $num = intdiv($num, 60);
	$mins  = $num % 60;      $num = intdiv($num, 60);
	$hours = $num % 24;      $num = intdiv($num, 24);
	$days  = $num;
	$uptime = $days.' d '.$hours.' h '.$mins.' m';
	$_SESSION["inifile"] = $fileName;
	//$pData = parse_ini_file("/home/transcoder/proj/test.ini", true);
	$pData = parse_ini_file($dPath."".$fileName, true);
	if (!empty($pData)) {
		$urlArray = $pData['Quad'];
		if (!empty($urlArray)) {
			$xpos = $urlArray['xpos'];
			$ypos = $urlArray['ypos'];
			$profile = $urlArray['profile'];
			if ($profile == '1') {
				$profile='Base';
			} else if ($profile == '2') {
				$profile='Main';
			} else if ($profile == '3') {
				$profile='High';
			} else {
				$profile='';
			}
			$bitrate = $urlArray['bitrate'] / 1000;
		}
		$camArray = $pData['RSTPURL'];
		if (!empty($camArray)) {
			$cam1 = $camArray['cam1.url'];
			$cam2 = $camArray['cam2.url'];
			$cam3 = $camArray['cam3.url'];
			$cam4 = $camArray['cam4.url'];
			$latency =  $camArray['latency'];
		}
		$systemArray = $pData['System'];
		if (!empty($systemArray)) {
			$nwkip = $systemArray['nwkip'];
			$nwkmask = $systemArray['nwkmask'];
			$sysname = $systemArray['sysname'];
			$nwkgip = $systemArray['nwkgip'];
			$sntpip = $systemArray['sntpip'];
			$syslogip = $systemArray['syslogip'];
			$ser = $systemArray['ser'];
			$model = $systemArray['model'];
			$firmware = $systemArray['firmware'];
			$hardware = $systemArray['hardware'];
			$pCheck = $systemArray['pchecksum'];
                        $currCheck = $systemArray['checksum'];

		}
	}
	include 'checksum.php';
?>
    </head>
    <body>
        <div class="container">
<?php include 'header.php';?>
            <div class="childcont">
                <div class="sidebar">
                    <a href="config.php">
                        <i class="fa fa-cog fa-lg" aria-hidden="true"></i>
                        Network
                    </a>
                    <a href="camerainput.php">
                        <i class="fa fa-camera" aria-hidden="true"></i>
                        Camera Input
                    </a>
                    <a href="quadoutput.php">
                        <i class="fa fa-video-camera" aria-hidden="true"></i>
                        Quad Output
                    </a>
                    <a href="system.php">
                        <i class="fa fa-desktop"  aria-hidden="true"></i>
                        Management
                    </a>
                </div>
		<div class="mainview">
                    <div class="view1">
                        <label class="sectionview">System</label>
			<div class="syssection">
			    <div class="sysparam">
                                <label class="sysoption">Model</label>
				<label class="sysvalue"><?php echo $model; ?></label>
                            </div>
                            <div class="sysparam">
                                <label class="sysoption">Serial Number</label>
				<label class="sysvalue"><?php echo $ser; ?></label>
                            </div>
                            <div class="sysparam">
                                <label class="sysoption">Firmware Version</label>
				<label class="sysvalue"><?php echo $firmware; ?></label>
                            </div>
                            <div class="sysparam">
                                <label class="sysoption">Hardware Version</label>
				<label class="sysvalue"><?php echo $hardware; ?></label>
                            </div>
			    <div class="sysparam">
                            	<label class="sysoption">Local Timer</label>
                            	<label class="sysvalue"><?php echo exec('date "+%a %b %Oe %H:%M:%S %Y"'); ?></label>
                            </div>
			    <div class="sysparam">
                            	<label class="sysoption">Uptime</label>
                            	<label class="sysvalue"><?php echo $uptime; ?></label>
                            </div>
			    <div class="sysparam">
                            	<label class="sysoption">Temperature</label>
                            	<label class="sysvalue"><?php echo $temp; ?> &#8451;</label>
                            </div>
			    <div class="sysparam">
                            	<label class="sysoption">CPU / Memory</label>
				<label class="sysvalue">(<?php echo $cpu; ?> / <?php echo $memPer; ?>) %</label>
                            </div>
                            <div class="sysparam">
                                <label class="sysoption">Quad Streaming</label>
				<label class="sysvalue"><?php echo $rStatus; ?></label>
                            </div>
			</div>
                    </div>
		    <div class="view2">
                        <label class="sectionview">Configuration</label>
                        <div class="cfgsection">
                            <div class="cfgparam">
                                <label class="cfgoption">System Name</label>
                                <label class="cfgvalue"><?php echo $sysname ?></label>
                            </div>
                            <div class="cfgparam">
                                <label class="cfgoption">IP Address</label>
                                <label class="cfgvalue"><?php echo $nwkip ?></label>
                            </div>
                            <div class="cfgparam">
                                <label class="cfgoption">Subnet Mask</label>
                                <label class="cfgvalue"><?php echo $nwkmask ?></label>
                            </div>
                            <div class="cfgparam">
                                <label class="cfgoption">Gateway IP</label>
                                <label class="cfgvalue"><?php echo $nwkgip ?></label>
                            </div>
                            <div class="cfgparam">
                                <label class="cfgoption">SNTP Server IP</label>
                                <label class="cfgvalue"><?php echo $sntpip ?></label>
                            </div>
                            <div class="cfgparam">
                                <label class="cfgoption">Syslog Server IP</label>
                                <label class="cfgvalue"><?php echo $syslogip ?></label>
                            </div>
                        </div>
                    </div>
                    <div class="view3">
                        <label class="sectionview">Camera Input</label>
			<div class="camsection">
                            <div class="camparam">
                        	<label class="camoption">Camera1 URL</label>
                        	<label class="camvalue"><?php echo $cam1; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Camera2 URL</label>
                        	<label class="camvalue"><?php echo $cam2; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Camera3 URL</label>
                        	<label class="camvalue"><?php echo $cam3; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Camera4 URL</label>
                        	<label class="camvalue"><?php echo $cam4; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Latency</label>
                        	<label class="camvalue"><?php echo $latency; ?> ms</label>
                            </div>
                            <div class="camparam">
                                <label class="quadsectionview">Quad Output</label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">X-Pos</label>
                        	<label class="camvalue"><?php echo $xpos; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Y-Pos</label>
                        	<label class="camvalue"><?php echo $ypos; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Profile</label>
                        	<label class="camvalue"><?php echo $profile; ?></label>
                            </div>
                            <div class="camparam">
                        	<label class="camoption">Peak Bitrate</label>
                        	<label class="camvalue"><?php echo $bitrate; ?> kbps</label>
                            </div>
                    	</div>
                    </div>
                </div>
            </div>
	</div>
<?php include 'footer.php';?>
    </body>
</html>
