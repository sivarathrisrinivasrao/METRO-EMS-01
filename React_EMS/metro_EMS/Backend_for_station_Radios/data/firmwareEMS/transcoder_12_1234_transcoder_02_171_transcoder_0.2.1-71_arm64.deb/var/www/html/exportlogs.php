<?php


function exportlogs() {
	$logs = shell_exec("sudo journalctl -u transcoder.service");
		header("Content-type: text/plain");
		header("Content-Disposition: attachment; filename=transcoder.log");
		echo "".$logs;
}

exportlogs();

?>
