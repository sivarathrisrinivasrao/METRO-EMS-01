<?php
echo 'factory reset';
session_start();
$dPath = $_SESSION["dPath"];
$fileName="default.ini";
$pData = parse_ini_file($dPath."".$fileName, true);
if (!empty($pData)) {
        $systemArray = $pData['System'];
        if (!empty($systemArray)) {
                $nwkip = $systemArray['nwkip'];
                $nwkmask = $systemArray['nwkmask'];
                $sysname = $systemArray['sysname'];
                $nwkgip = $systemArray['nwkgip'];
                $sntpip = $systemArray['sntpip'];
                $syslogip = $systemArray['syslogip'];
                //print_r($nwkmask);
        }
}
//$cmd = 'sudo bash changeip.sh '.$nwkip.' '.$nwkmask.' '.$nwkgip.' '.$syslogip.' '.$sntpip;
//shell_exec($cmd);
$username = 'transcoder';
$newpass = 'transcoder';
$cmd = sprintf(
        "echo '%s:%s' | sudo chpasswd",
           escapeshellarg($username),
           escapeshellarg($newpass)
        );
        exec($cmd);

chmod("/opt/transcoder/vtrans.sh",775);
exec("sudo chown www-data vtrans.sh");
$remtrans = "sudo rm ".$dPath."transcoder.ini";
exec($remtrans);
shell_exec("sudo systemctl stop transcoder");
sleep(3);
$remsh = "sudo rm -rf ".$dPath."vtrans.sh";
exec($remsh);

$str =  "sudo /opt/transcoder/vtranscoder \"( videotestsrc ! omxh264enc ! rtph264pay name=pay0 pt=96 )\" &";
$myfile = fopen("/opt/transcoder/vtrans.sh", "w");
fwrite($myfile,$str);
fclose($myfile);
chmod("/opt/transcoder/vtrans.sh",775);
exec("sudo chown www-data /opt/transcoder/vtrans.sh");
sleep(1);
$cmd = 'sudo bash changeip.sh '.$nwkip.' '.$nwkmask.' '.$nwkgip.' '.$syslogip.' '.$sntpip.' '.$sysname;
shell_exec($cmd);
//$url = 'http://'.$_SERVER['HTTP_HOST'].'/system.php';
//header( "Location: $url" );

?>
