<?php include 'saveToIni.php';
function saveConfig() {
	echo '<script>alert("Welcome to Geeks for Geeks")</script>'; 
	testcall('testttttt');
	}
?>
