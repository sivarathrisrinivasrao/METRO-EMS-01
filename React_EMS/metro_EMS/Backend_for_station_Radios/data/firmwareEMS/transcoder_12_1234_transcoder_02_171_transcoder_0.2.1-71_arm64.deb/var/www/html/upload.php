<?php

	$target_dir = "/opt/transcoder/";
	$target_file = $target_dir . "transcoder.ini";
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

	//echo '<script language="javascript">alert("'.basename($_FILES["fileToUpload"]["name"]).'"); </script>';
	
// Check if image file is a actual image or fake image
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		//$target_path = $target_path.basename( $_FILES['fileToUpload']['name']);   
		if(file_exists($target_file)){
			$execu = "sudo cp ".$target_file." ".$target_file.".tmp";
			echo '<script language="javascript">console.log("'.$execu.'"); </script>';
			$rmFile = "sudo rm ".$target_file;
			echo '<script language="javascript">console.log("'.$rmFile.'"); </script>';
			shell_exec($execu);
			sleep(0.5);
			shell_exec($rmFile);
			sleep(0.5);
			
		}
		if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_file)) {  
			echo "File uploaded successfully!"; 
			sleep(2);
                        $url = 'http://'.$_SERVER['HTTP_HOST'].'/applyProfile.php?meth=save';
                        header( "Location: $url" );
 
		} else{  
			echo "Sorry, file not uploaded, please try again!";  
		}  
	} 
?>
