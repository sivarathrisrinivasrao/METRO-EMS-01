dpkg -i /tmp/apache/libapr1_1.6.5-1_arm64.deb
dpkg -i /tmp/apache/libaprutil1_1.6.1-2_arm64.deb
dpkg -i /tmp/apache/libaprutil1-dbd-sqlite3_1.6.1-2_arm64.deb
dpkg -i /tmp/apache/libaprutil1-ldap_1.6.1-2_arm64.deb
dpkg -i /tmp/apache/apache2-bin_2.4.29-1ubuntu4.14_arm64.deb
dpkg -i /tmp/apache/apache2-data_2.4.29-1ubuntu4.14_all.deb
dpkg -i /tmp/apache/apache2-utils_2.4.29-1ubuntu4.14_arm64.deb
dpkg -i /tmp/apache/apache2_2.4.29-1ubuntu4.14_arm64.deb

echo 'Installing web server completed++++++++++++++'

dpkg -i /tmp/php2/php-common_69ubuntu2_all.deb
dpkg -i /tmp/php2/php7.2-common_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/php7.2-json_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/php7.2-readline_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/php7.2-opcache_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/php7.2-cli_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/libapache2-mod-php7.2_7.2.3-1ubuntu1_arm64.deb
dpkg -i /tmp/php2/php7.2-sqlite3_7.2.3-1ubuntu1_arm64.deb

echo 'Installing Support packages+++++++++++++++++++'

dpkg -i /tmp/other/whois_5.3.0_arm64.deb


echo 'Installing gStreamer++++++++++++++++'

dpkg -i /tmp/libgstrstp/gir1.2-gst-rtsp-server-1.0_1.14.5-0ubuntu1~18.04.1_arm64.deb
dpkg -i /tmp/libgstrstp/libgstrtspserver-1.0-dev_1.14.5-0ubuntu1~18.04.1_arm64.deb
dpkg -i /tmp/libgstrstp/libgstrtspserver-1.0-0_1.14.5-0ubuntu1~18.04.1_arm64.deb


echo 'updating Ntp server++++++++++++++'

dpkg -i /tmp/other/libopts25_5.18.12-4_arm64.deb
dpkg -i /tmp/other/ntp_4.2.8p10+dfsg-5ubuntu7.3_arm64.deb

cp /tmp/other/ntp.conf /etc/ntp.conf


echo 'www-data ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers

echo '*.* @192.168.1.100:514' >> /etc/rsyslog.conf

rm -rf /var/www/html/index.html

chmod 775 /opt/transcoder
chown www-data /opt/transcoder

echo 'Installing services'

sudo systemctl daemon-reload
sudo systemctl enable transcoder.service
sudo systemctl start transcoder

/etc/init.d/apache2 restart


echo '*******Creating default user "transcoder"++++++++++++++'

sudo useradd -d /home/transcoder -m transcoder
echo "transcoder:transcoder" | chpasswd

usermod --shell /bin/bash transcoder

echo 'transcoder ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers

ipaddr="192.168.1.10"
mask="255.255.255.0"
gwipaddr="192.168.1.1"

read -p "Do you want to proceed with applying default configuration(IP: 192.168.1.10, MASK:255.255.255.0, Gateway:192.168.1.1) (y/n)? " answer
case "$answer" in
    n|N )
        read -p "Do you want to proceed with existing IP Address configuration (y/n)? " ans
        case "$ans" in
        n|N )
            read -p "Enter IP Address : " ipaddr
            read -p "Enter Netmask : " mask
            read -p "Enter Gateway IP : " gwipaddr
	    echo "IP : $ipaddr Mask: $mask Gateway: $gwipaddr"
            if [ ! -z "$ipaddr" ] && [ ! -z "$mask" ] && [ ! -z "$gwipaddr" ]; then
                sudo bash /var/www/html/changeip.sh $ipaddr $mask $gwipaddr 192.168.1.100 192.168.1.100 Transcoder
    	    else
                echo Entered input values are not valid, retained existing IP configuration.
	    fi
	;;
        *)
            echo Retained existing IP configuration.
	;;
        esac
    ;;
    * )
        echo Applying default configuration
        sudo bash /var/www/html/changeip.sh 192.168.1.10 255.255.255.0 192.168.1.1 192.168.1.100 192.168.1.100 Transcoder
    ;;
esac

echo '********************Configuring server is completed***************'
echo '********************Use the below details for login***************'
echo '********login : "transcoder"  Pwd: "transcoder" ******************'
