#!/bin/bash

trap term_signal TERM
trap term_signal INT

SCRIPT_PATH="$(cd $(dirname "$0") >/dev/null 2>&1 && pwd)"

. ${SCRIPT_PATH}/inc/ini-parser.sh
. ${SCRIPT_PATH}/inc/check-host.sh
. ${SCRIPT_PATH}/inc/print-help.sh

CONF_TRANS="/opt/transcoder/transcoder.ini"
RUN_STATUS="/tmp/transcoder.state"
CHECK_STATUS="/tmp/transcoder.check"
TRANSCODER_SERVICE="transcoder.service"

###########################################################################################################
# TERM signal handling
term_signal() {
   print_sec "TERM signal... exit"
   exit 0
}

###########################################################################################################
# Get 'Quad' params from ini file
configuration_read() {
   RSTPURL_DATA=$(config_read_section "${CONF_TRANS}" 'RSTPURL')
   C_CAM0_URL=$(config_read_param "${RSTPURL_DATA}" 'cam1.url')
   C_CAM1_URL=$(config_read_param "${RSTPURL_DATA}" 'cam2.url')
   C_CAM2_URL=$(config_read_param "${RSTPURL_DATA}" 'cam3.url')
   C_CAM3_URL=$(config_read_param "${RSTPURL_DATA}" 'cam4.url')
}

###########################################################################################################
# Check stream alive
check_streams() {
   checkhost_ping "$(config_gethost ${C_CAM0_URL})"
   CAM0_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

   checkhost_ping "$(config_gethost ${C_CAM1_URL})"
   CAM1_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

   checkhost_ping "$(config_gethost ${C_CAM2_URL})"
   CAM2_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

   checkhost_ping "$(config_gethost ${C_CAM3_URL})"
   CAM3_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

   checkhost_write_status "${CHECK_STATUS}" "${CAM0_STATE}${CAM1_STATE}${CAM2_STATE}${CAM3_STATE}"
}

###########################################################################################################
# Compare alive state and run state
check_streams_status_changed() {
   checkhost_compare_files "${RUN_STATUS}" "${CHECK_STATUS}"
   return ${?}
}

###########################################################################################################
###########################################################################################################
###########################################################################################################
while true
 do
    configuration_read
    check_streams
    check_streams_status_changed
    if [ "${?}" != "0" ]; then
        print_sec "Detected diferent stream state"
        [ "${STREAM0_CHANGE}" != "" ] && print_sec "Stream[0] is ${STREAM0_CHANGE}"
        [ "${STREAM1_CHANGE}" != "" ] && print_sec "Stream[1] is ${STREAM1_CHANGE}"
        [ "${STREAM2_CHANGE}" != "" ] && print_sec "Stream[2] is ${STREAM2_CHANGE}"
        [ "${STREAM3_CHANGE}" != "" ] && print_sec "Stream[3] is ${STREAM3_CHANGE}"
        print_sec "Restarting transcoder service"
        if [ -f /tmp/transcoder.lock ]; then 
           print_sec "[WARNING] Service transcoder locked or restarting in progress. Ignoring restart process"
        else
           systemctl restart ${TRANSCODER_SERVICE}
        fi
    fi
    sleep 5
done