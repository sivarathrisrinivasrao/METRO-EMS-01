#!/bin/bash

SCRIPT_PATH="$(cd $(dirname "$0") >/dev/null 2>&1 && pwd)"

. ${SCRIPT_PATH}/inc/ini-parser.sh
. ${SCRIPT_PATH}/inc/check-host.sh

CONF_TRANS="/opt/transcoder/transcoder.ini"
CONF_OUT="/run/transcoder.conf"
RUN_STATUS="/tmp/transcoder.state"
RUN_CFG=""
RTPSRC=""

###########################################################################################################
service_lock() {
  touch /tmp/transcoder.lock
}

###########################################################################################################
service_unlock() {
  rm -f /tmp/transcoder.lock
}

###########################################################################################################
config_check() {
   if [ ! -f /opt/transcoder/transcoder.ini ]; then
     cp /opt/transcoder/default.ini /opt/transcoder/transcoder.ini
     chown www-data /opt/transcoder/transcoder.ini
   fi
}

###########################################################################################################
# Lock service 
service_lock

###########################################################################################################
# Check transcoder.ini exist
config_check
# Get 'Quad' params from ini file
QUAD_DATA=$(config_read_section "${CONF_TRANS}" 'Quad')
C_XPOS=$(config_read_param "${QUAD_DATA}" 'xpos')
C_YPOS=$(config_read_param "${QUAD_DATA}" 'ypos')
C_PROFILE=$(config_read_param "${QUAD_DATA}" 'profile')
C_BITRATE=$(config_read_param "${QUAD_DATA}" 'bitrate')
C_PEAK_BITRATE=$(echo "${C_BITRATE}*1.2/1" | bc)
# Get 'Quad' params from ini file
RSTPURL_DATA=$(config_read_section "${CONF_TRANS}" 'RSTPURL')
C_CAM0_URL=$(config_read_param "${RSTPURL_DATA}" 'cam1.url')
C_CAM1_URL=$(config_read_param "${RSTPURL_DATA}" 'cam2.url')
C_CAM2_URL=$(config_read_param "${RSTPURL_DATA}" 'cam3.url')
C_CAM3_URL=$(config_read_param "${RSTPURL_DATA}" 'cam4.url')
# Get 'Latency' params from ini file
C_LATENCY=$(config_read_param "${RSTPURL_DATA}" 'latency')

###########################################################################################################
# Check stream alive

checkhost_ping "$(config_gethost ${C_CAM0_URL})"
CAM0_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

checkhost_ping "$(config_gethost ${C_CAM1_URL})"
CAM1_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

checkhost_ping "$(config_gethost ${C_CAM2_URL})"
CAM2_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

checkhost_ping "$(config_gethost ${C_CAM3_URL})"
CAM3_STATE=$([ "${?}" == "0" ] && echo "1" || echo "0")

checkhost_write_status "${RUN_STATUS}" "${CAM0_STATE}${CAM1_STATE}${CAM2_STATE}${CAM3_STATE}"

if [ "${CAM0_STATE}" == "1" ]; then
   RTPSRC="${RTPSRC} rtspsrc latency=${C_LATENCY} location=${C_CAM0_URL} ! rtph264depay ! h264parse ! avdec_h264 ! comp.sink_0"
else
   RTPSRC="${RTPSRC} videotestsrc pattern=zone-plate ! comp.sink_0"
   echo "Stream[0] is DOWN.. ignored"
fi

if [ "${CAM1_STATE}" == "1" ]; then
   RTPSRC="${RTPSRC} rtspsrc latency=${C_LATENCY} location=${C_CAM1_URL} ! rtph264depay ! h264parse ! avdec_h264 ! comp.sink_1"
else
   RTPSRC="${RTPSRC} videotestsrc pattern=zone-plate ! comp.sink_1"
   echo "Stream[1] is DOWN.. ignored"   
fi

if [ "${CAM2_STATE}" == "1" ]; then
   RTPSRC="${RTPSRC} rtspsrc latency=${C_LATENCY} location=${C_CAM2_URL} ! rtph264depay ! h264parse ! avdec_h264 ! comp.sink_2"
else
   RTPSRC="${RTPSRC} videotestsrc pattern=zone-plate ! comp.sink_2"
   echo "Stream[2] is DOWN.. ignored"   
fi

if [ "${CAM3_STATE}" == "1" ]; then
   RTPSRC="${RTPSRC} rtspsrc latency=${C_LATENCY} location=${C_CAM3_URL} ! rtph264depay ! h264parse ! avdec_h264 ! comp.sink_3"
else
   RTPSRC="${RTPSRC} videotestsrc pattern=zone-plate ! comp.sink_3"
   echo "Stream[3] is DOWN.. ignored"   
fi

###########################################################################################################
# Prepare run string for transcoder-service

RUN_CFG="(videomixer name=comp \
sink_0::xpos=0 sink_0::ypos=0 \
sink_1::xpos=${C_XPOS} sink_1::ypos=0 \
sink_2::xpos=0 sink_2::ypos=${C_YPOS} \
sink_3::xpos=${C_XPOS} sink_3::ypos=${C_YPOS} ! \
videoconvert ! omxh264enc profile=${C_PROFILE} control-rate=1 bitrate=${C_BITRATE} peak-bitrate=${C_PEAK_BITRATE} preset-level=0 ! rtph264pay config-interval=-1 name=pay0 pt=96 ${RTPSRC} )"

echo "---=== Prepare RUN string ===---"
echo "RUN_CFG=\"${RUN_CFG}\""
echo "================================"

echo "RUN_CFG=\"${RUN_CFG}\"" > ${CONF_OUT}

###########################################################################################################
# Unlock service 
service_unlock

