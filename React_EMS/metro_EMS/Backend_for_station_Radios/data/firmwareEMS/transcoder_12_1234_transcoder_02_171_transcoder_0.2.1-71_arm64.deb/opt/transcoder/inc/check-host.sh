###########################################################################################################
#
#   Check host functions
#
###########################################################################################################

###########################################################################################################
#
# Ping host
#

checkhost_ping() {
     local PARAM_HOST="${1}"
     ping "${PARAM_HOST}" -A -W 1 -c 3 -q > /dev/null 2>&1
     return ${?}
}

###########################################################################################################
#
# Write status file
#

checkhost_write_status() {
     local PARAM_FILE="${1}"
     local PARAM_STATUS="${2}"
     echo "${PARAM_STATUS}" | tr -d ' ' | tr -d '\n' > ${PARAM_FILE}
}

###########################################################################################################
#
# Compare state
#
_compare_state() {
    local PARAM_STATE="${1}"
    local PARAM_CHECK="${2}"
    if [ "${PARAM_STATE}" != "${PARAM_CHECK}" ]; then
      if [ "${PARAM_CHECK}" == "0" ]; then
         echo "DOWN"
      else
         echo "UP"
      fi
    fi

}

###########################################################################################################
#
# Compare files
#

checkhost_compare_files() {
    local PARAM_FILE_STATE="${1}"
    local PARAM_FILE_CHECK="${2}"
    STREAM0_CHANGE=""
    STREAM1_CHANGE=""
    STREAM2_CHANGE=""
    STREAM3_CHANGE=""

     cmp -s "${PARAM_FILE_STATE}" "${PARAM_FILE_CHECK}" > /dev/null 2>&1
     RET_RES=${?}
     if [ "${RET_RES}" != "0" ]; then
       STREAM_STATE="$(cat ${PARAM_FILE_STATE})"
       STREAM_CHECK="$(cat ${PARAM_FILE_CHECK})"
       STREAM0_CHANGE=$(_compare_state "${STREAM_STATE:0:1}" "${STREAM_CHECK:0:1}")
       STREAM1_CHANGE=$(_compare_state "${STREAM_STATE:1:1}" "${STREAM_CHECK:1:1}")
       STREAM2_CHANGE=$(_compare_state "${STREAM_STATE:2:1}" "${STREAM_CHECK:2:1}")
       STREAM3_CHANGE=$(_compare_state "${STREAM_STATE:3:1}" "${STREAM_CHECK:3:1}")
     fi
     return ${RET_RES}
}
